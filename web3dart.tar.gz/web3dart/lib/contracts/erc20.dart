export '../src/generated/erc20.g.dart';
